const express=require('express');//create a express
const fs=require("fs/promises");
const storage=require('node-persist');//installed node persist for storing the task
const bodyParser=require('body-parser');
const jsonParser=bodyParser.json();
const cors=require('cors');//installed cors for request from front end and give resource from backend
const app=express();
app.use(cors());
app.use(express.json());


storage.init(//storage is intialized and storage link is placed in directory and put time to live in false
  {
    dir:'C:/Users/manib/node.js/React Assignment2/Backend/.node-persist/storage',
    ttl:false,
  }
);
app.get("/gettask",async(req,res)=>{//create an endpoint gettask and get the values from storage using try catch
  try {
   const task= await storage.values(); 
    res.send({task});
  } catch (error) {
    console.error('Error clearing tasks:', error);
  }
});
app.post("/addtask",async(req,res)=>{
    //used "post" with their ID for Adding the task
  const {task}=req.body;
const result=await storage.setItem(task,{task});//used "setItem" for storing
   res.json({message:"Task Added successfully ",result});
});
 async function clear(){//created a clear function for clearing the storage while restarting the application
  await storage.init();
 await storage.clear();
 }
clear().then(()=>{app.listen(5000,async()=>{  console.log("server started on Port 5000");
});
});