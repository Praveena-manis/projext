const jwt = require("jsonwebtoken");
const {JWT_SECRET} = require('../config'); //get jwtsecret from config

const mongoose = require("mongoose");
const UserModel = mongoose.model("UserModel"); //get usermodel

module.exports = (req, res, next)=>{  //for login used authorization from header
    const {authorization} = req.headers;
    //Bearer fsfsjfsfgjgj
    if(!authorization){
        return res.status(401).json({error: "User not logged in"});
    }
    const token = authorization.replace("Bearer ", "");  //get token from storage and replace with bearer
        jwt.verify(token, JWT_SECRET, (error, payload)=>{ //verify the user with token and secret
        if(error){
            return res.status(401).json({error: "User not logged in"});
        }
        const {_id} = payload; //in payload get user id and check it in database
        UserModel.findById(_id)
        .then((dbUser)=>{
            req.user = dbUser;
            next();//goes to the next middleware or goes to the REST API
        })
    });
}