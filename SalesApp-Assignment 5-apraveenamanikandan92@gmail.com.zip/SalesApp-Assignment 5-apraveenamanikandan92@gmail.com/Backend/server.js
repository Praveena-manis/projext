const express=require('express');
const app=express();
const cors=require('cors'); //used cors for connecting backend and frontend
const mongoose=require('mongoose');
const {MONGOBD_URL}=require('./config'); //get database url from config
mongoose.connect(MONGOBD_URL);
mongoose.connection.on('connected',()=>{ //create a connection in mongodb
    console.log("connected");
});
mongoose.connection.on('error',(error)=>{
    console.log("error while connecting database");
});
require('./model/usermodel'); //get postmodel and usermodel
require('./model/postmodel');
app.use(cors());
app.use(express.json());
app.use(require('./routes/user_route')); //get user route and post route
app.use(require('./routes/post_route'));
app.listen(5000,()=>{
    console.log("Server started");
})