const mongoose=require('mongoose'); //use mongoose for storing  

const userSchema=new mongoose.Schema({ //created userschema for storing firstname,lastname ,email and password
    firstName:{
        type:String,
        trim:true,
        required:true
    },
    lastName:{
        type:String,
        trim:true,
        required:true
    },
    email:{
        type:String,
        unique: true,
        lowercase: true,
        trim: true,
        required: true
    },
    password:{
        type:String,
        required:true
    }
});
mongoose.model("UserModel",userSchema);