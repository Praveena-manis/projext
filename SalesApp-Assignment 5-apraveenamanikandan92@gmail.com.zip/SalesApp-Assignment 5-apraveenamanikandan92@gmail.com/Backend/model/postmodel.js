const mongoose=require('mongoose'); 
const userSchema=new mongoose.Schema({//create salesschema for storing product name,quantity,amount and total
    productName:{
        type:String,
        required:true
    },
    quantity:{
        type:Number,
        required:true
    },
    amount:{
        type:Number,
        required:true
    },
    total: { type: Number, 
         },     

},{timestamps:true}); //used timestamp
mongoose.model("PostModel",userSchema);