module.exports={
    MONGOBD_URL:"mongodb://localhost:27017/Sales",
    JWT_SECRET:"svjshbffejefhdjfnjdf"
}//create sales database with secret code