const express=require('express');
const router=express.Router(); //user router for routing
const mongoose=require('mongoose');
const PostModel=mongoose.model('PostModel')
const protectedRoute=require('../middleware/protectedResources');

router.post("/addsales",protectedRoute,async(req,res)=>{ //used post for adding sales
    try{
    const {productName,quantity,amount}=req.body; 
    if(!productName||!quantity||!amount)
    {
        return res.status(400).json({error:"one or more fields are empty"})
    }
  const total=quantity*amount;//multiply the quantity and amount
    const addSales=new PostModel({
        productName,
        quantity,
        amount,
        total,
    })  
   await addSales.save();    //save the details
   res.status(200).send(addSales);
           
}catch(error){
    res.status(500).json({error:"internal server error"})
} 
});

router.get("/topsales",protectedRoute,async(req,res)=>{//used protected route from middleware
    try {   
        const author_id=req._id //get user id 
        const today = new Date(); //get todays date
        today.setUTCHours(0, 0, 0, 0); //set hours to midnight
        const topSales=await PostModel.find({ //used find for getting todays date and used sort for sorting from descending order and used linit 5 for 5 top sales
            author_id,
            createdAt:{$gte:today}
        })
         .sort({total:-1})
        .limit(5)
        res.status(201).send(topSales);
     
    } catch (error) {
        res.status(500).json({error:"internal server error"})
    }
})
router.get("/revenue",protectedRoute,async(req,res)=>{
    try {
        // Get today's date
        const today = new Date();
        today.setUTCHours(0, 0, 0, 0); // Set time to midnight
  
        // Query for today's revenue
        const result = await PostModel.aggregate([
          {
            $match: {
              createdAt: { $gte: today }
            }
          },
          {
            $group: {
              _id: null,
              total: { $sum: "$total" }
            }
          }
        ]);
  
        // Send the total revenue as a JSON response
        res.json({ total: result[0] ? result[0].total : 0 });
      } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal Server Error' });
      }
    });

module.exports=router;