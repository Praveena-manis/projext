import { API_BASE_URL } from '../config';
import './Addsale.css';
import React,{useState} from 'react';
import axios from 'axios';
import {toast,ToastContainer} from 'react-toastify'; //used toast for pop up message
//used form for adding sale used col with different screen size and used button in form input type is text for productname and number for quantity and amount
function Addsale() {
    const [productName,setProductName]=useState("");
    const [quantity,setQuantity]=useState("");
    const [amount,setAmount]=useState("")
    const [loading,setLoading]=useState(false);
    const CONFIG_OBJ = {//used jwt token for only authorized person can used
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + localStorage.getItem("token")
        }
      }
      const addsale=(e)=>{
        e.preventDefault();
        setLoading(true);
        const requestData={productName,quantity,amount}//request productname,quantity and amount using axios for post method and used jwt token
        axios.post(`${API_BASE_URL}/addsales`,requestData,CONFIG_OBJ)
        .then((result)=>{
            if(result.status===200){
                setLoading(false);
                toast.success("successfully added",{//used toast for successfully added
                position:toast.POSITION.TOP_RIGHT,
            });
            }
            setProductName('');//set field empty
            setQuantity('');
            setAmount('');
        })
        .catch((error)=>{
            console.log(error);
            setLoading(false);
            toast.error("error occurred",{ //used toast for error
                position:toast.POSITION.TOP_RIGHT,
            });
        }
        )    
    }
    return (
        <div className="container w-100"> {/*used container */ }
            <div className='row'>
                <h3>ADD SALE ENTRY</h3>
                <div className='col-md-12 col-lg-12 col-sm-12'> {/*used different screen size for making responsive*/}
                {loading?   <div className="spinner-grow text-primary" role="status">    
                <span className="sr-only">Loading...</span>
                </div>:''} {/*used spinner for loading*/}
                <form onSubmit={(e)=>addsale(e)}> { /*used onsubmit and label ,input type as text for product name*/ }
                    <label className="mt-1 fs-30 fw-bold">Product Name</label>
                    <input type="text" value={productName} onChange={(e)=>setProductName(e.target.value)} className='form-control'/> 
                    <br></br>    
                    <label className="mt-1 fs-30 fw-bold">Quantity</label>   {/*used input type as number for quantity*/}            
                    <input type="number" value={quantity} onChange={(e)=>setQuantity(e.target.value)} className='form-control'/>
                    <br></br>
                    <label className="mt-1 fs-30 fw-bold">Amount</label>            {/*used input type as number for amount */}   
                    <input type="number" value={amount} onChange={(e)=>setAmount(e.target.value)} className='form-control'/>
                    <br></br>
                    <div className='row'>
                    <button type="submit" className="btn btn-primary">AddSales</button>
                    </div>
                    <ToastContainer/>
                </form>
                </div>
            </div>
        </div>
    );
}
export default Addsale;