import React,{useEffect, useState} from "react";
import { API_BASE_URL } from "../config";
import axios from 'axios';
import {toast} from 'react-toastify';

function Revenue()
{ //used config obj for authorization
    const CONFIG_OBJ = {
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + localStorage.getItem("token")
        }
      }
    const [total,setTotal]=useState([]) //used empty array for useState
    const revenue=async()=>{
        const result=await axios.get(`${API_BASE_URL}/revenue`,CONFIG_OBJ); //used axios and get the total revenue
        if(result.status===200){
            setTotal(result.data.total);
        }else{
            toast.error("Error occurred",{
                position:toast.POSITION.TOP_RIGHT, //used toast for error
            })
        }
    }
    useEffect(()=>{
        revenue(); //get revenue function for display
    },[])
    return(
        <>
        <div className="row text-centered">
        <h3>TODAY'S REVENUE is {total}</h3>  {/*get total of todays revenue*/}
        </div> 
        </>
        
    );
}
export default Revenue;