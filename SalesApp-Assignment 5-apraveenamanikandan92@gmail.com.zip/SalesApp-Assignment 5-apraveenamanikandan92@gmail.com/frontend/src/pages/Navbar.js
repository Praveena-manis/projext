import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import './Navbar.css';
import {NavLink,useNavigate} from 'react-router-dom';
import {useDispatch,useSelector} from 'react-redux';
function NavbarComp() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const user = useSelector(state => state.userReducer);
  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    dispatch({ type: "LOGIN_ERROR" }); //used dispatch for login error
    navigate("/register"); //used navigate for navigate to register page
  }
//used container ,nav navbar and used navlink from react router dom 
  return (
    <div className="bg">
       <Navbar expand="lg"data-bs-theme="dark" className="bg-body-primary">
      <Container fluid>
        <Navbar.Brand >SALES APP</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">{/*used localstorage is not null i.e only authorized user can access addsales and top5sales and total revenue*/}
          <Nav className="me-auto">
          {localStorage.getItem("token") != null ?  <>  <NavLink className='nav-link'  to="/Addsales">ADD SALES</NavLink> 
            <NavLink className='nav-link' to="/Topsale">TOP 5 SALES</NavLink>
            <NavLink className='nav-link'  to="/Revenue">TODAY'S TOTAL REVENUE</NavLink></>:''}
            {localStorage.getItem("token") == null ? <><NavLink  className='nav-link' to="/Login">LOGIN</NavLink>
            <NavLink className='nav-link' to="/Register">REGISTER</NavLink></>  :''}
            {localStorage.getItem("token") != null ?     <Nav.Link className='nav-link'  onClick={()=>logout()}>LOGOUT</Nav.Link>:''}
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
    </div>
   
  );
}

export default NavbarComp;