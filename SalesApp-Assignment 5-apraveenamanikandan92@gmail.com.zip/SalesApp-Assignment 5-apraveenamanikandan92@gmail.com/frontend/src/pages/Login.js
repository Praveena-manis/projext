import {useNavigate} from 'react-router-dom';
import axios from 'axios';
import {useDispatch} from 'react-redux';
import './Addsale.css';
import { API_BASE_URL } from '../config';
import React, { useState } from 'react';
import { ToastContainer, toast } from "react-toastify";
//created a form with type text for firstname and lastname, type email for Email and type password for password
function Login() {
   
    const [email,setEmail]=useState("");
    const [password,setPassword]=useState("");
    const [loading,setLoading]=useState(false);
    const dispatch=useDispatch(); //used dispatch and navigate 
    const navigate=useNavigate();
    const login=(e)=>{
        e.preventDefault();
        setLoading(true);
        const requestData={email,password} //post email and password for login
        axios.post(`${API_BASE_URL}/login`,requestData)
        .then((result)=>{
            if(result.status===200){
                setLoading(false);
               localStorage.setItem("token",result.data.result.token); //get stored the token and user information
               localStorage.setItem("user",JSON.stringify(result.data.result.user));
               dispatch({type:'LOGIN_SUCCESS',payload:result.data.result.user});
               setLoading(false);
                      navigate('/addsales');    //after succesful login navigate to addsales page
            }
        })
        .catch((error)=>{
            console.log(error);
            setLoading(false);
            toast.error("Ivalid email or password!", { //used toast for displaying error
                position: toast.POSITION.TOP_RIGHT,
                })
        })
}
    return (
        <div className='container w-100'> {/*create a container */}
            <div className='row'>
                <h3 className='text-centered'>LOGIN FORM </h3> 
                <div className='col-lg-12 col-md-12 col-sm-12'>
                {loading?   <div class="spinner-grow text-primary" role="status"> {/*used spinner for loading*/}
                <span class="sr-only">Loading...</span>
                </div>:''}
                <form onSubmit={(e)=>login(e)}> {/*used onsubmit for event*/}
                    <label className="mt-1 fs-30 fw-bold">Email</label>      {/*used input type as text as email for mailid and password for password*/}         
                    <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} className='form-control'/>
                    <br></br>
                    <label className="mt-1 fs-30 fw-bold">Password</label>               
                    <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} className='form-control'/>
                    <br></br>
                    <div className='row'>
                    <button type="submit" className="btn btn-primary">Login</button>
                    </div>
                    <ToastContainer/>
                </form>
            </div>
            </div>
        </div>
    );
}

export default Login;