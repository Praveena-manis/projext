import axios from 'axios';
import './Addsale.css';
import { API_BASE_URL } from '../config';
import React, { useState } from 'react';
import { ToastContainer, toast } from "react-toastify";
//created a form with type text for firstname and lastname, type email for Email and type password for password
function Register() {
    const [firstName,setFirstName]=useState("");
    const [lastName,setLastName]=useState("");
    const [email,setEmail]=useState("");
    const [password,setPassword]=useState("");
    const [loading,setLoading]=useState(false);

    const register=(e)=>{
        e.preventDefault();
        setLoading(true);
        const requestData={firstName,lastName,email,password}//request firstname,lastname,email and password  using axios in post method
        axios.post(`${API_BASE_URL}/register`,requestData)
        .then((result)=>{
            if(result.status===201){
                setLoading(false);
                
                toast.success("successfully registered",{ //used toast for successful message
                position:toast.POSITION.TOP_RIGHT,
            });
            }
            setFirstName(''); //set field empty
            setLastName('');
            setEmail('');
            setPassword('');
        })
        .catch((error)=>{
            console.log(error);
            setLoading(false);
            toast.error("error occurred",{ //used toast for error message
                position:toast.POSITION.TOP_RIGHT,
            });
        }
        )    
    }
    return (
        <div className='container w-100'>
            <div className='row'>
                <h3 className='text-centered'>REGISTRATION FORM </h3>
                <div className='col-lg-12 col-md-12 col-sm-12'>{/*used spinner for loading*/}
             {loading?   <div class="spinner-grow text-primary" role="status"> 
                <span class="sr-only">Loading...</span>
                </div>:''}
                <form onSubmit={(e)=>register(e)}>
                    <label className="mt-1 fs-30 fw-bold">First Name</label> {/*used type as text for firstname and lastname email as email and password as password used onchange event */}
                    <input type="text" value={firstName} onChange={(e)=>setFirstName(e.target.value)} className='form-control'/> 
                    <br></br>    
                    <label className="mt-1 fs-30 fw-bold">Last Name</label>               
                    <input type="text" value={lastName} onChange={(e)=>setLastName(e.target.value)} className='form-control'/>
                    <br></br>
                    <label className="mt-1 fs-30 fw-bold">Email</label>               
                    <input type="email" value={email} onChange={(e)=>setEmail(e.target.value)} className='form-control'/>
                    <br></br>
                    <label className="mt-1 fs-30 fw-bold">Password</label>               
                    <input type="password" value={password} onChange={(e)=>setPassword(e.target.value)} className='form-control'/>
                    <br></br>
                    <div className='row'>
                    <button type="submit" className="btn btn-primary">Register</button>
                    </div>
                    <ToastContainer/>
                </form>
            </div>
            </div>
        </div>
    );
}

export default Register;