import React,{useEffect,useState} from 'react';
//used table to display data 
import axios from 'axios';
import {toast,ToastContainer} from 'react-toastify';
import { API_BASE_URL } from '../config';
function Topsale()
{
    const [sales,setSales]=useState([]);//used useState empty array 
    const CONFIG_OBJ = {
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + localStorage.getItem("token") // get token from local storage
        }
      }
    const topsale=async()=>{
        const result=await axios.get(`${API_BASE_URL}/topsales`,CONFIG_OBJ); //used axios to get data from backend
        if(result.status===201){
            setSales(result.data);
        }else{
            toast.error("Error occurred",{
                position:toast.POSITION.TOP_RIGHT, //used toast for displaying message
            })
        }
    }
    useEffect(()=>{
        topsale(); //used to display the data
    },[])
    return(
        <div className='container w-100 '>
             <div className='row'>
             <h3 className='text-centered'>TOP 5 SALES </h3> 
            <div className='col-lg-12 col-md-12 col-sm-12'> {/*used differrent screen for responsive image*/}
                <table className='table table-responsive table-bordered mt-3' style={{textAlign:'center'}}> {/*used table to map the data*/}
                    <thead>
                    <tr>
                            <th>Id:</th>
                            <th> Product Name</th>
                            <th>Quantity</th>
                            <th>Sale Amount</th>
                        </tr>
                    </thead>  
                    <tbody >
                    {sales &&
                  sales.map((user) => ( 
              <tr>
                <td>{user._id}</td>
                <td>{user.productName}</td>
                <td>{user.quantity}</td> 
                <td>{user.total}</td>
              </tr>
            ))}
                    </tbody>
                </table> {/*used map for displaying the data */}
                <ToastContainer/>
            </div>
        </div>
        </div>
       
    );
}
export default Topsale;