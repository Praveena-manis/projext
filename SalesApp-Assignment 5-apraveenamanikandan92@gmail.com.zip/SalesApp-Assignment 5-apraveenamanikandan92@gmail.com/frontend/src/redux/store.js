import { createStore } from "redux"; //used store to hold the complete state
import { combineReducer } from "./combineReducer";
export const store=createStore(
    combineReducer
)


