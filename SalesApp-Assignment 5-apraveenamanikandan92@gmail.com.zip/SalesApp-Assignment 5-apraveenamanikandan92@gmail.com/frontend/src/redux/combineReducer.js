import { combineReducers } from "redux"; //combine different into single combine reducer function
import { userReducer } from "./userReducer";

export const combineReducer = combineReducers({ userReducer: userReducer });