const initialState={ //use reducer for taking current state and action and return the new state
    user:{}
}
export const userReducer=(state=initialState,action)=>{ //if it is succes return the updated state else error return the initial state
    switch (action.type) {
        case "LOGIN_SUCCESS":
            return{
                ...state,user:action.payload
            };
        case "LOGIN_ERROR":
            return initialState;
        default:
            return state;
    }

}