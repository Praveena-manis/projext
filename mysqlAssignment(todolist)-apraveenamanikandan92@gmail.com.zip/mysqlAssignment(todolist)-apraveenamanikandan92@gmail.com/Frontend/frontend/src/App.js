import React, { useEffect,useState } from 'react';  //import react,useeffect,usestate
import './App.css';//import css file
const App=()=>{//create a function using app
  const [task,setTask]=useState('');//create an array with empty string
 const [data,setData]=useState([]);
  const handlesubmit=async (e)=>{
    try {
      e.preventDefault();
    const resp=  await fetch("http://localhost:5000/newtask",//fetch data using  from localhost and add task
    {
        method:"POST",//post method
        headers:{"Content-Type":"application/json"},
        body:JSON.stringify({task:task})//store task from addtask
      })
      if(resp.status===201)
      {
        alert("task added");
      }
      fetchData();
    } catch (err) {
            console.log(err.message);
    }

  };
 const Alert=()=>{
  alert("Deleted")
 }
  const fetchData=async ()=>{//fetchdata function to get a task from localhost
    try {
      const response=await fetch('http://localhost:5000/gettask');//get a task from localhost
      const data=await response.json();//get a json data and store in data
      setData(data);
    } catch (err) {
      console.log(err.message);
    }
  }
  const deleteData =(id) => {//delete the task using id 
    fetch(`http://localhost:5000/deletetask/${id}`, {
      method: 'DELETE',
    })
    fetchData()
    .then(()=>Alert())
      .catch(error => console.error('Error deleting todo:', error));
  };
  useEffect(()=>{//used to fetch data and updating in the DOM
    fetchData();
  },[]);
 return (
    <div className="App">
    <h1 className='text-center'>To do List App</h1>
    <form className='col-md-6 offset-3'onSubmit={handlesubmit}>
      <div className='form-group'>      
        <label>Enter the task:</label>
        <input type='text'placeholder='Enter the task' className='form-control'//created a form with input type in text and placeholder and used setTask to change the value while enter in the input type
         onChange={(e)=>setTask(e.target.value)}/> 
      <button type='submit' className='btn btn-success'>Add Task</button>
      </div>
       <div className='form1'>
        <div className="taskslist">
          <h4>Tasks:</h4>
          </div>   
         </div> 
    </form>
    <form>
    {data.map((todo)=>{//used map function for displaying the list and called delete function
        return(<li key={todo.id}>
          {todo.task}         
           <button onClick={() => deleteData(todo.id)}>X</button>
                  </li>   
                 )}
    )}

    </form>
   
    </div>
 )
}
export default App;


