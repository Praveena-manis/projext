const express=require('express');
const mysql=require('mysql');//used mysql
const cors=require('cors');//used cors
const app=express();   
app.use(cors());
const bodyParser=require('body-parser'); 
app.use(express.json());
const jsonParser=bodyParser.json();
const connection=mysql.createConnection({//used createConnection for creating a connection using xampp for mysql 
    host:"localhost",
    user:"root",
    password:"",
    database:"todolist"
})
connection.connect((err)=>{//checking mysql connection
    if (err) {
        console.log(err);
    }
    else
    {
        console.log("connected");
    }
})
app.get("/createdb",(req,res)=>{//used get to create a database todolist
    connection.query(`CREATE DATABASE todolist`,(err,result)=>{
        if(err)
        {
            console.log(err);
        }
        res.send("Database Created")
    });
});
app.get("/createtable",(req,res)=>{//used get for creating a new table todolist using create
    connection.query(`CREATE TABLE IF NOT EXISTS task(id INT NOT NULL AUTO_INCREMENT,task VARCHAR(255)NOT NULL,PRIMARY KEY(id))`,(err)=>{
        if(err)
        {
            console.log(err);
        }
        else{
            res.send("table created")
        }
    });
});
app.post("/newtask",(req,res)=>{//used post to add newtask using the insert query
    const {task} = req.body;
    connection.query(`INSERT INTO task(task) VALUES("${task}")`,
        (err, result) => {
            if (err) {
                console.log(err);
            }else{
                res.send({message:"inserted",result})
            }
        })
});
app.get("/gettask",(req,res)=>{//used get to get all the task using the select query
    connection.query(`SELECT * FROM task`,(err,result)=>{
        if(err)
        {
            console.log(err);
        }
        else{
            res.send(result)
        }
    });
})
app.delete("/deletetask/:id",(req,res)=>{//delete a task used delete with query delete with id
    const id =req.params.id;
    connection.query(`DELETE FROM task WHERE id=?`,[id],(err,result)=>{
        if(err)
        {
            console.log(err);
        }
        else{
            res.send(result);
        }
    });
})
app.listen(5000,()=>{
    console.log("server is running");
});