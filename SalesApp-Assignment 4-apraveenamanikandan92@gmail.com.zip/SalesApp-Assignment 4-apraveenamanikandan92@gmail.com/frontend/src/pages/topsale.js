import React from 'react';
//used table to display data 
function Topsale()
{
    return(
        <div className='container-fluid'>
             <div className='row'>
             <h3 className='text-centered'>TOP 5 SALES </h3> 
            <div className='col-lg-12 col-md-12 col-sm-12'>
                <table className='table table-bordered mt-3' style={{textAlign:'center'}}> 
                    <thead>
                    <tr>
                            <th>#</th>
                            <th>Sales Id:</th>
                            <th> Product Name</th>
                            <th>Quantity</th>
                            <th>Sale Amount</th>
                        </tr>
                    </thead>  
                    <tbody >
                        <tr >
                            <td><b>1</b></td>
                            <td>s1212</td>
                            <td>Laptop</td>
                            <td>2</td>
                            <td>90000</td>
                        </tr>
                        <tr>
                            <td><b>2</b></td>
                            <td>s1423</td>
                            <td>Mobile</td>
                            <td>5</td>
                            <td>85000</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        </div>
       
    );
}
export default Topsale;