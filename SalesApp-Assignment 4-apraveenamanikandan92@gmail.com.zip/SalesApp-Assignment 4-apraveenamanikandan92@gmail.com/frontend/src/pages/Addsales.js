import Form from 'react-bootstrap/Form';
import './Addsale.css';
import Button from 'react-bootstrap/Button';
//used form for adding sale used col with different screen size and used button in form input type is text for productname and number for quantity and amount
function Addsale() {
    return (
        <div className="container w-100">
            <div className='row'>
                <h3>ADD SALE ENTRY</h3>
                <div className='col-md-12 col-lg-12 col-sm-12'> 
                    <Form>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1"> 
                            <Form.Label>Product Name</Form.Label>
                            <Form.Control type="text" />
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                            <Form.Label>Quantitys</Form.Label>
                            <Form.Control type="number" />
                        </Form.Group>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
                            <Form.Label>Amount</Form.Label>
                            <Form.Control type="number" />
                        </Form.Group>
                    </Form>
                    <Button className="button" variant="primary">submit</Button>
                </div>
            </div>
        </div>
    );
}
export default Addsale;