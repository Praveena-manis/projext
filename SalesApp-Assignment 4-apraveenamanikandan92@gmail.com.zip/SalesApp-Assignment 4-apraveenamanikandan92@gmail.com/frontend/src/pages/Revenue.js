function Revenue()
{
    return(
        <h3>TODAY'S REVENUE IS 175000</h3>
    );
}
export default Revenue;