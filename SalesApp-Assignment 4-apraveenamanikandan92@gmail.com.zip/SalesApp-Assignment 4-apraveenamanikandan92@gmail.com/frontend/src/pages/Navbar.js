import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import './Navbar.css';
import {NavLink} from 'react-router-dom';
function NavbarComp() {
//used container ,nav navbar and used navlink from react router dom 
  return (
    <div className="bg">
       <Navbar expand="lg"data-bs-theme="dark" className="bg-body-primary">
      <Container fluid>
        <Navbar.Brand  href="/Addsales">SALES APP</Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className="me-auto">
            <NavLink className='nav-link'  to="/Addsales">ADD SALES</NavLink>
            <NavLink className='nav-link' to="/Topsale">TOP 5 SALES</NavLink>
            <NavLink className='nav-link'  to="/Revenue">TODAY'S TOTAL REVENUE</NavLink>
            <NavLink  className='nav-link' to="/Login">LOGIN</NavLink>
            <NavLink className='nav-link' to="/Register">REGISTER</NavLink>
            <Nav.Link className='nav-link'  to="#link">LOGOUT</Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
    </div>
   
  );
}

export default NavbarComp;