import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import './Addsale.css';
//created a form with type text for firstname and lastname, type email for Email and type password for password
function Register() {
    return (
        <div className='container w-100'>
            <div className='row'>
                <h3 className='text-centered'>REGISTRTION FORM </h3>
                <div className='col-lg-12 col-md-12 col-sm-12'>
                <Form>
                <Form.Group className="mb-3" controlId="formGroupEmail">
                        <Form.Label>First Name</Form.Label>
                        <Form.Control type="text" />
                    </Form.Group>
                <Form.Group className="mb-3" controlId="formGroupEmail">
                        <Form.Label>Last Name</Form.Label>
                        <Form.Control type="text" />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formGroupEmail">
                        <Form.Label>Email</Form.Label>
                        <Form.Control type="email" />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formGroupPassword">
                        <Form.Label>Password</Form.Label>
                        <Form.Control type="password" />
                    </Form.Group>
                </Form>
                <Button className="button" variant="primary">submit</Button>
            </div>
            </div>
        </div>
    );
}

export default Register;