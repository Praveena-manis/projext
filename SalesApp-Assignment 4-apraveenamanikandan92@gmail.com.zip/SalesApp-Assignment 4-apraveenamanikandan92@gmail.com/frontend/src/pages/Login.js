import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import './Addsale.css';
//used bootstrap for form and button with different screen size and form with type email for Email and password for password
function Login() {
    return (
        <div className='container w-100'>
            <div className='row'>
                <h3 className='text-centered'>LOGIN FORM </h3>
                <div className='col-lg-12 col-md-12 col-sm-12'>
                <Form>
                    <Form.Group className="mb-3" controlId="formGroupEmail">
                        <Form.Label>Email</Form.Label>
                        <Form.Control type="email" />
                    </Form.Group>
                    <Form.Group className="mb-3" controlId="formGroupPassword">
                        <Form.Label>Password</Form.Label>
                        <Form.Control type="password" />
                    </Form.Group>
                </Form>
                <Button className="button" variant="primary">submit</Button>
            </div>
            </div>
        </div>
    );
}

export default Login;