import { BrowserRouter,Routes,Route } from 'react-router-dom';
import './App.css';
import Addsales from './pages/Addsales';
import NavbarComp from './pages/Navbar';
import Login from './pages/Login';
import Register from './pages/Register';
import Topsale from './pages/topsale';
import Revenue from './pages/Revenue';//import various bootstrap and route and pages
function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <NavbarComp/>
      <Routes>
        <Route exact path="/" element={<Addsales/>}> </Route>
        <Route exact path="/addsales" element={<Addsales/>}> </Route>
        <Route exact path="/login" element={<Login/>}> </Route>
        <Route exact path="/register" element={<Register/>}> </Route>
        <Route exact path="/topsale" element={<Topsale/>}> </Route>
        <Route exact path="/revenue" element={<Revenue/>}> </Route>
      </Routes>
      </BrowserRouter>    
    </div>
  );
}

export default App;
