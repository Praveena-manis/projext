import React from 'react';
import Header from './header';
import Cover from './homecover';
import Slider from './slider';
import Footer from './footer';
function Home(){
    return( 
        <div className="home"> {/*routed 4 components in Home*/}
            <Header/>
            <Cover/>
            <Slider/>
            <Footer/>
        </div>
    )
}
export default Home;