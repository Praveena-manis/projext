import './App.css';
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import Home from './components/home';

function App() { //used browser router from router and routed home with / endpoint
  return (
    <BrowserRouter>
    <div ClassName="App">
      <Routes>
        <Route path="/" element ={<Home/>}></Route>

      </Routes>
    </div>
    </BrowserRouter>
  );
}

export default App;
