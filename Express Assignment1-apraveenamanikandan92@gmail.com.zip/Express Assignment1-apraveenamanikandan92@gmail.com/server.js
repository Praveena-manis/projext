const express=require('express');//start new  express application
const storage=require('node-persist');//create storage for JSON data
var bodyParser=require('body-parser');//extracts the entire body portion of an reques
var jsonParser=bodyParser.json();//json type data
const app=express();//create server 
app.use(express.json());//parse the incoming request with json
storage.init();//initilaize storage
app.get("/allstudents",async(req,res)=>{//used  "get" for displaying all students 
    const result=await storage.values();//get stored data from postman
    let myResult='';
    for(let a of result)//used for loop
    myResult+=` <h2>Student_id:${a.Student_id} </h2> 
                <h2>Name:${a.Name}</h2>
                <h3>GPA:${a.GPA}</h3>`
    res.send(`<h1>All Students Data!</h1>`+myResult);//send the result and displaying in html
});
app.get("/student/:Student_id",async(req,res)=>{// used "get" for getting the student with their ID
    const Student_id=req.params.Student_id;//get their ID by req.params
  const result=await storage.getItem(Student_id);
  if(result){//used if-else condition for displaying the student id is matched else display no student
        res.send(` <h1>Student Details</h1>
                    <h2>Student_id:${result.Student_id} </h2>
                    <h2>Name:${result.Name}</h2>
                    <h3>GPA:${result.GPA}</h3>`);
  }else{
    res.send(`<h1>No students available in the given ID</h1>`);
  }
});
app.get("/topper",async(req,res)=>{//used "get" for displaying the topper of the class
    const result=await storage.values();
  //  console.log(result);
   let max=result[0];
   for(let i=1;i<result.length;i++)//used for loop
    {
        if(result[i].GPA>max.GPA){//used if condition for getting highest gpa
       max=result[i];
     }
    }
       res.send(` <h1>Student Details</h1>
                  <h2>Student_id:${max.Student_id} </h2>
                 <h2>Name:${max.Name}</h2>
                 <h3>GPA:${max.GPA}</h3>`);
      });
app.post("/student/:id",jsonParser,async(req,res)=>{//used "post" with their ID for Adding the student details
   const {Student_id,Name,GPA}=req.body;
 const result=await storage.setItem(Student_id,{Student_id,Name,GPA});//used "setItem" for storing
    res.send({message:"Students Details Added successfully ",result});
});
app.delete("/student/:id",async(req,res)=>{//used "delete" for remove the student data
    const Student_id=req.params.id;
    const result=await storage.getItem(Student_id);
    if(result){
        await storage.removeItem(Student_id);
        res.send(`<h2>Student Detail Deleted with ID: ${Student_id}`);
    }else{
        res.send(`<h2>No student details available</h2>`);
    }
});
app.listen(5000,()=>console.log("server started"));//using listen in 5000 port and server started